<script language="javascript">var PageType ="{{NEW_GAME_PAGE}}"; var ids ="{{NEW_GAME_IDS}}";</script>
<div class="content">
	{{NEW_GAMES}}
</div>

{{FOOTER_CONTENT}}

