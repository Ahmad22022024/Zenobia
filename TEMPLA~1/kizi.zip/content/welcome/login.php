<div class="gamemonetize-main span100">
	<div class="gamemonetize-door">
		<div class="gamemonetize-door-container">
			<form class="signin-form" method="post">
				<div class="form-header">@header_login@</div>

				<div class="vByg5">
					<input type="text" name="login_id" placeholder="@user_email@">
				</div>
				<div class="vByg5">
					<input type="password" name="login_key" placeholder="@password@">
				</div>
				{{IS_REDIRECT_LOGIN}}
				<div class="_yt10 _a-r">
					<input class="submit-btn btn-p btn-p4" type="submit" value="@sign_in@">
				</div>
			</form>
		</div>
	</div>
</div>