<link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/admin/admin.css">
<link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/admin.css">
<link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/admin-responsive.css">
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,700&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese">
<link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/admin-style.css">
<link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/libs/owl/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/libs/owl/owl.theme.css">
<link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/libs/sweetalert.css">
<link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/libs/toast.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<!-- Custom css for select2 -->
<style>
    .select2-container--default .select2-selection--multiple, .select2-results__option {
        background: #3e4454;
    }
</style>