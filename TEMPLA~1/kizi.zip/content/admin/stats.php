<div class="_header-section admin-hh-style">
	<span class="_content-title _content-color-a"><img class="img-50" src="{{CONFIG_THEME_PATH}}/image/icon-color/shield.png"> @administration@</span>
</div>
<div class="general-box stats-box-container _yt10 _yb10">
	<div class="stats-box" title="@games_installed@" style="width:100%;">
		<div class="stats-icon-box stats-bg-one"><i class="fa fa-gamepad"></i></div>
		<div class="stats-info stats-color-one ellipsis">{{ADMIN_STATS_GAMES}}</div>	
	</div>
	<div class="stats-box" title="@categories_registered@" style="width:100%;">
		<div class="stats-icon-box stats-bg-three"><i class="fa fa-users"></i></div>
		<div class="stats-info stats-color-three ellipsis">{{ADMIN_STATS_CATEGORIES}}</div>	
	</div>
	{{NEWS}}
</div>