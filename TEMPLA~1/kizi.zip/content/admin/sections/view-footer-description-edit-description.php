<div>
	<div style="margin-bottom: 10px;">
		Description
	</div>
	<div>
		<textarea rows="15" style="min-height: 339px;" name="footer_description" class="editor-js _text-input _tr5 tinymce">{{EDIT_FOOTER_DESCRIPTION_VALUE}}</textarea>
	</div>
</div>