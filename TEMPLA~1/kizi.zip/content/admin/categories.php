<div class="gamemonetize-main-headself">
	<i class="fa fa-bookmark"></i>
</div>
{{CATEGORIES_SECTION_CONTENT}}