<div class="page-wrapper">
	<div class="gamemonetize-main pull-right span79">
		{{PAGE_ADMIN_CONTENT}}
	</div>

	<div class="gamemonetize-nav pull-left span20">
		<div class="gamemonetize-nav-headself" style="padding: 39px;">
			 DASHBOARD
		</div>
		{{ADMIN_NAVIGATION_MENU}}
	</div>
</div>