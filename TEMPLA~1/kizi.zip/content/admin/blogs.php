<div class="gamemonetize-main-headself">
	<i class="fa fa-bookmark"></i>
</div>
{{BLOGS_SECTION_CONTENT}}