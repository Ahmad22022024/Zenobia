<div class="post">
    <a href="{{SEARCH_GAME_URL}}" class="game-item">
        <img src="{{SEARCH_GAME_IMAGE}}" alt="{{SEARCH_GAME_NAME}}">
        <p class="post-name" data-url="{{SEARCH_GAME_VIDEO_URL}}" data-scale="1.2" data-translate="-23px,-25px">{{SEARCH_GAME_NAME}}</p>

        {{SEARCH_GAME_FEATURED}}
</div>