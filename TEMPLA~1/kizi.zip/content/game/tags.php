<div id="Gameinner" class="bgs" style="max-width: 100%;margin-bottom:70px;">
    <div class="partners fn-clear">

    {{NEW_TAGS}}
    </div>
</div>