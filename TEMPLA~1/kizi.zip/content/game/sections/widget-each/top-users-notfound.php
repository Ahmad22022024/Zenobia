<li class="item">
	<div class="small _a-c">@no_users_found@</div>
</li>