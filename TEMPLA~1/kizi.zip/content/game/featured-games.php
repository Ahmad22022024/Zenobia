<ul class="card">
	{{FEATURED_GAMES_LIST}}
</ul>