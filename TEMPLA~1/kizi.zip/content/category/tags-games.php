<div class="category-section-top" style="text-align:center;font-size:20px;margin-bottom:10px;margin-top:20px;color:white;">
	<span data-href="{{CONFIG_SITE_URL}}/categories"><i class="fa fa-tags"></i> @tags@: <i class="fa fa-chevron-right"></i></span><strong style="color:#fc0">{{TAGS_NAME}}</strong>
</div>

<div class="content">
	<div id="content" style="margin-bottom:50px;">
		{{TAGS_GAMES_LIST}}

	</div>
</div>

<div class="bgs bottomtext fn-clear" style="padding:20px; width:90% !important;">    
	{{FOOTER_DESCRIPTION}}
</div>
{{FOOTER_CONTENT}}