<div class="small" style="text-align:center;font-size:18px;margin-bottom:10px;margin-top:20px;">
	<div>@no_games_found@</div>
</div>