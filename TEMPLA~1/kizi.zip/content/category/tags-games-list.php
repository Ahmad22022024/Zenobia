<div class="post">
    <a href="{{TAGS_GAME_URL}}" class="game-item">
        <img src="{{TAGS_GAME_IMAGE}}" alt="{{TAGS_GAME_NAME}}">
        <p class="post-name" data-url="{{TAGS_GAME_VIDEO_URL}}" data-scale="1.2" data-translate="-23px,-25px">{{TAGS_GAME_NAME}}</p>
        <span class="featured_icon"></span>
    </a>
</div>