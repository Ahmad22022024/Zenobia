<script language="javascript">var PageType ="{{NEW_GAME_PAGE}}"; var ids ="{{NEW_GAME_IDS}}";</script>



<div id="Gameinner" class="bgs">
    <div class="partners fn-clear">
{{CATEGORIES_LIST}}
    </div>
    <div class="bottomtext fn-clear" style="padding:20px;">    
        {{FOOTER_DESCRIPTION}}
    </div>
</div>


{{FOOTER_CONTENT}}